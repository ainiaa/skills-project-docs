# L5/L6 实现与测试语义审查 v1

作者：Jeff.Liu

审查时点：2026-10-31T17:52:41.585348+08:00。实际读回 app/legacy_export.py 和 tests/test_registrations.py，沿 input/session→csv→summarize→stdout 的真实命令链核对。作用域为SIM-REG-001模拟快照，不使用业务Mock替代被测算法。

## 测试先行与源码绑定

先从sources/legacy_export.py逐字节复制到app/legacy_export.py；未实现前用当前仓库采集器执行真实CLI unittest。RED执行14例，13 failed、1 passed、0 error，没有导入/收集错误；错误来自业务断言，例如旧S1=6而期望3、重复/取消仍计行、缺pending字段、坏输入仍给人数。完整stdout/stderr在evidence/red-command.json，逐例结果在execution-red.json；trace-red.json绑定当时app全文摘要，原样基线另存evidence/baseline-legacy_export.py。

然后只修改工作副本app/legacy_export.py，保留summarize(rows, session)和CLI参数，新增字段/校验/冲突优先分组。历史第一次GREEN实际执行14例全部passed，0 failed/error/skipped/expected_failure；历史execution-green.json的build为当时app/legacy_export.py整个文件SHA256，并非只绑定manifest。初轮tests文件从RED到初轮GREEN字节不变。旧RED中的app路径按历史版本绑定，当前app变化是预期；基线副本用于核查，不把RED回执重新绑成GREEN。

## AC与断言的实际对应

| 必需AC | 测试方法（RegistrationTests） | 核实的业务断言 |
|---|---|---|
| AC-001 | test_sample_s1_snapshot_and_pending_source；test_sample_s2_is_independent | 原样CSV真实CLI，S1 count=3、R7五字段+原因、has_pending/notice，S2完整结果=1；invoke_file比较前后字节 |
| AC-002 | test_duplicate_cross_session_and_row_order；test_employee_identity_is_opaque | 同员工跨渠道S1=1、S2=1且反序不变；E01/e01/前导空格员工号各自不同，不猜测归一 |
| AC-003 | test_conflict_group_isolated_before_cancel_filter；test_all_cancelled_contributes_zero | confirmed/cancelled组不计且两原行pending；其他员工计1、另场次计1；反序不改结果；全取消0且无pending |
| AC-004 | test_missing_employee_rows_are_not_merged；test_sample_s1_snapshot_and_pending_source | 多空员工号分别列出、count0，每项五个原字段与reason，样本R7来源字段逐值检查 |
| AC-005 | test_header_only_and_absent_session；test_missing_file_reports_failure_without_count；test_missing_columns_and_empty_critical_fields；test_invalid_status_in_other_session_invalidates_snapshot；test_malformed_csv_and_invalid_encoding；test_extra_columns_are_ignored_without_changing_source | 无记录0并提示；缺文件/列、四关键字段空、非法状态、长短行、未闭引号、无效UTF-8/空文件均非零+stderr+空stdout；其他场次坏状态仍整份失败；额外列保留原表而不参与结果 |
| AC-006 | test_reconciled_new_snapshot_retains_old_snapshot_and_result | 从原快照真实读取R7另存E05新快照，S1变4；原表字节不变、原快照重跑结果相同、旧结果JSON可保留；不是新功能自动回写 |

最终trace.json逐一使用以上真实ID，FR来源prd-traceability.md中的FR-001/FR-002声明，AC来源唯一prd.md，全部6项required=true；每个FR都有必需AC。初轮采集器发现14例，初轮trace校验实际ready=true（evidence/trace-validation.json）；修复轮的最终17例与绑定见下节。数量不能代替上表的断言检查。

## 根因和有限复核

根因是按场次计行而非按已明确的状态/身份粒度；共享summarize一次修复。完整组判断冲突先于取消过滤，保留原行且不跨组扩散；校验全部行先于场次筛选，符合整份输入失败的明确决定。源码没有打开写模式、网络调用、外部服务或新增依赖。原始四份资料和PRD字节保持；后续handoff前再次核对冻结摘要。

无真实业务UAT、生产部署、数据修正或收益验证。未执行规模基准/覆盖率百分比/变异测试，不声称native-v1完成门禁；本轮按明确的Lifecycle unittest采集协议验证。主控独立复核发现的空白边界及修复见下节；该复核来自父上下文，不冒充真人试读。

## 独立复核发现与第二轮TDD

主控从模拟决定和现有实现独立复核，复现纯空白employee_id被计1而无pending；其原始命令证据副本在evidence/review-whitespace-repro.json与evidence/whitespace-repro.csv。控制器在boundary-clarification.md明确为本期空值边界：只strip判是否有内容，保留非空员工号原值和pending中的原空白。record_id/session_id/source仅空白要输入失败。原PRD和原始资料不变。

先新增test_whitespace_employee_ids_preserve_raw_pending_rows、test_whitespace_critical_fields_fail_without_count、test_duplicate_header_is_rejected三项；对初轮GREEN源码执行17例：2 failed（两项空白边界）、15 passed、0 error，证明不是导入错误。execution-red-2.json与evidence/red-command-2.json为真实结果；该旧源码另存history/app-green-1.py。

仅三处修复：四关键字段的有内容判断（status仍由合法枚举校验）、员工号入组判断、缺员工号pending判断。非空员工号不trim，大小写不变；原值字段照原行保留。最终execution-green-2.json实跑17例，全部passed，0 failed/error/skipped/expected_failure。初轮及第二轮RED、旧GREEN均保留，不覆盖或把旧回执改绑新版本。最终tests全文摘要与trace一致，build直接绑定最终app全文。

第二轮新增断言具体检查：两个全空白员工号count=0、两条分别pending且保留原始空白；三个关键定位字段全空白均非零退出、stderr定位字段、stdout无人数；重复表头明确拒绝。既有opaque身份测试继续验证E01/e01/前导空格非空号分别计数。

交叉FR映射理由：AC-001除FR-001计数，也断言R7可回查及原表只读，因此同时支持FR-002；AC-003除计数，还断言冲突组每个原字段+reason，支持FR-002；AC-005除FR-002输入恢复，还断言失败无人数JSON、防止把错误当确认数，支持FR-001。其余原归属保持，不复制AC、不改编号；最终trace显式列多FR关联。主文仍是唯一规则源。
