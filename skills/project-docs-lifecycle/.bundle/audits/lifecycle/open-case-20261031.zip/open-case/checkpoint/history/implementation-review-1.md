# L5/L6 实现与测试语义审查 v1

作者：Jeff.Liu

审查时点：2026-10-31T17:52:41.585348+08:00。实际读回 app/legacy_export.py 和 tests/test_registrations.py，沿 input/session→csv→summarize→stdout 的真实命令链核对。作用域为SIM-REG-001模拟快照，不使用业务Mock替代被测算法。

## 测试先行与源码绑定

先从sources/legacy_export.py逐字节复制到app/legacy_export.py；未实现前用当前仓库采集器执行真实CLI unittest。RED执行14例，13 failed、1 passed、0 error，没有导入/收集错误；错误来自业务断言，例如旧S1=6而期望3、重复/取消仍计行、缺pending字段、坏输入仍给人数。完整stdout/stderr在evidence/red-command.json，逐例结果在execution-red.json；trace-red.json绑定当时app全文摘要，原样基线另存evidence/baseline-legacy_export.py。

然后只修改工作副本app/legacy_export.py，保留summarize(rows, session)和CLI参数，新增字段/校验/冲突优先分组。第一次GREEN实际执行14例全部passed，0 failed/error/skipped/expected_failure；execution-green.json的build为app/legacy_export.py整个文件SHA256，并非只绑定manifest。tests文件从RED到GREEN字节不变。旧RED中的app路径按历史版本绑定，当前app变化是预期；基线副本用于核查，不把RED回执重新绑成GREEN。

## AC与断言的实际对应

| 必需AC | 测试方法（RegistrationTests） | 核实的业务断言 |
|---|---|---|
| AC-001 | test_sample_s1_snapshot_and_pending_source；test_sample_s2_is_independent | 原样CSV真实CLI，S1 count=3、R7五字段+原因、has_pending/notice，S2完整结果=1；invoke_file比较前后字节 |
| AC-002 | test_duplicate_cross_session_and_row_order；test_employee_identity_is_opaque | 同员工跨渠道S1=1、S2=1且反序不变；E01/e01/前导空格员工号各自不同，不猜测归一 |
| AC-003 | test_conflict_group_isolated_before_cancel_filter；test_all_cancelled_contributes_zero | confirmed/cancelled组不计且两原行pending；其他员工计1、另场次计1；反序不改结果；全取消0且无pending |
| AC-004 | test_missing_employee_rows_are_not_merged；test_sample_s1_snapshot_and_pending_source | 多空员工号分别列出、count0，每项五个原字段与reason，样本R7来源字段逐值检查 |
| AC-005 | test_header_only_and_absent_session；test_missing_file_reports_failure_without_count；test_missing_columns_and_empty_critical_fields；test_invalid_status_in_other_session_invalidates_snapshot；test_malformed_csv_and_invalid_encoding；test_extra_columns_are_ignored_without_changing_source | 无记录0并提示；缺文件/列、四关键字段空、非法状态、长短行、未闭引号、无效UTF-8/空文件均非零+stderr+空stdout；其他场次坏状态仍整份失败；额外列保留原表而不参与结果 |
| AC-006 | test_reconciled_new_snapshot_retains_old_snapshot_and_result | 从原快照真实读取R7另存E05新快照，S1变4；原表字节不变、原快照重跑结果相同、旧结果JSON可保留；不是新功能自动回写 |

trace.json逐一使用以上真实ID，FR来源prd-traceability.md中的FR-001/FR-002声明，AC来源唯一prd.md，全部6项required=true；每个FR都有必需AC。采集器发现14例，所有声明ID均实跑。trace校验实际ready=true，回执在evidence/trace-validation.json。数量不能代替上表的断言检查。

## 根因和有限复核

根因是按场次计行而非按已明确的状态/身份粒度；共享summarize一次修复。完整组判断冲突先于取消过滤，保留原行且不跨组扩散；校验全部行先于场次筛选，符合整份输入失败的明确决定。源码没有打开写模式、网络调用、外部服务或新增依赖。原始四份资料和PRD字节保持；后续handoff前再次核对冻结摘要。

无真实业务UAT、生产部署、数据修正或收益验证。未执行规模基准/覆盖率百分比/变异测试，不声称native-v1完成门禁；本轮按明确的Lifecycle unittest采集协议验证。已向主控请求独立复核；其结果如有将单独保存，不把作者自查称作独立盲审。
