# SIM-REG-001：L6 已测试冻结检查点

作者：Jeff.Liu

本包为独立新上下文前向实跑的本地模拟案例；L0–L6 已完成，L7–L10 均未开始。不是实际访谈、真实业务批准、生产发布或收益证明。协调/研发/测试由主控模型及授权执行上下文承担，运营/组织者由模拟测试扮演。

身份固定为 SIM-EVENT / SIM-REG-001，唯一业务主文 [prd.md](prd.md) 仍为 draft-1 原字节；真实FR声明在 [prd-traceability.md](prd-traceability.md)。原 discovery 原样冻结；当前包复制其资料，新增模拟落实/边界决定、实现、测试和证据。原四份资料在 sources/，源文件未覆盖。

先读 [simulation-resolution.md](simulation-resolution.md)、[boundary-clarification.md](boundary-clarification.md)、[current-stage-review.md](current-stage-review.md)、[design-current.md](design-current.md)、[implementation-review.md](implementation-review.md)。[production-backlog.md](production-backlog.md) 保留真实人员/渠道/兼容/效果未知，原gap审查在history/quality.json。

实际结果：原样基线14例中13项业务断言失败、1项通过、0执行错误；独立复核发现空白身份缺陷后，第二轮17例有2项业务断言失败、0执行错误；最小修复后最终17项全部passed。完整RED/GREEN日志和逐例回执均保留。最终trace直接绑定app/legacy_export.py整个文件与当前tests全文，6项必需AC均有实际ID和语义走读，包含跨FR映射。

当前测试对象运行方式（在包目录内）：

```sh
python3 app/legacy_export.py --session S1 --input sources/registrations.csv
```

实际测试结果包含S1 count=3、R7待核实，S2 count=1；纯空白身份逐行pending并保留原值，冲突先于取消过滤，输入失败非零/stderr且stdout无人数。没有写原表、自动修正来源或新平台。

下一独立上下文应先使用随包相同工具验证：

```sh
PYTHONDONTWRITEBYTECODE=1 python3 tooling/lifecycle_quality.py handoff --root . --contract handoff.json
```

核查通过后复制整个冻结包到新的工作目录接续，保持本包不变；不要在这里复跑会写新回执的采集器。工作副本如需重测，应使用当前trace和新输出文件名，旧回执不可覆盖。当前lifecycle-record.json revision=2，无待复核依赖，分支incomplete是因为L7–L10还未执行。

next_action从L7开始，仅允许本地模拟UAT、隔离目录发布、输入故障及同构建恢复、交接与效果待观察记录；具体计划见remaining-stages.md。禁止真实生产、外部消息、真实数据修改和桌面应用。质量/trace/handoff通过只证明本地绑定一致，不增加授权。

handoff.json的files绑定全部必需资料、源码、测试、当前/历史证据、工具和记录；为避免自引用，handoff本身及其随后产生的验证回执不纳入files。该包不是宿主自动切换聊天或跨账户权限的验证。

最终主控独立模型复核已关闭本轮空白防护与交叉追踪两项问题，并独立实跑17项全过；见independent-review.md与execution-parent-review.json。该复核不是实际业务批准。

## 当前工具只读修复后的重新采集

独立接续首次发现直接运行Python校验会创建导入缓存；原始包及首次接续结果独立保留。当前包是新检查点，替换工具快照并重新执行17项测试，当前执行证据为 execution-tool-fix.json，record仅追加验证观察并按CAS升至revision2；原PRD、业务源码、测试和trace不变。旧工具/审查/交接定义见history/tool-readonly-fix，仅属历史，不用旧回执宣称当前工具已验证。新上下文从L7继续，真实业务效果仍未观察。
