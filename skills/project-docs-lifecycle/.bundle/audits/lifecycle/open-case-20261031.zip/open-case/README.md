# 无预设解决方案的模拟案例

作者：Jeff.Liu

起点只有本目录的 raw-input.md、operator-notes.md、registrations.csv 和 legacy_export.py：业务痛点、合并快照和现有计行命令，没有指定去重口径、状态优先级或研发方案。独立模型先取证/提问，取得明确标为模拟的业务答复，再比较不做、人工、配置和研发，选择最小 CLI 改造。

[L6 冻结检查点](checkpoint/README.md) 保存本次实际产物及历史，不会在复跑时重写原始取证。唯一 PRD、问题身份、两项 FR 和六项 AC 延续；17 项真实业务测试覆盖正常、边界、错误与核实后重跑。发现纯空白身份缺陷后另走一轮先红后绿，保留旧实现/回执。质量审查最初发现的负责人、接口契约缺口也保存，随后仅在本次模拟范围落实。

| 阶段 | 资料 |
|---|---|
| L0–L1 | [原始输入与取证](checkpoint/investigation.md)、[追问](checkpoint/questions.md)、[模拟答复](checkpoint/clarifications-simulated.md)、原命令回执 |
| L2 | [方案比较与分流](checkpoint/decision.md)，含人工与配置替代路径 |
| L3 | [唯一 PRD](checkpoint/prd.md)、[FR/AC 来源](checkpoint/prd-traceability.md)、结构检查与模型走读 |
| L4 | [当前设计](checkpoint/design-current.md)、模拟输出契约、故障恢复及真实落地待办 |
| L5 | app/legacy_export.py、tests/test_registrations.py、两轮 RED/GREEN、[实现走读](checkpoint/implementation-review.md)与构建摘要 |
| L6 | [trace.json](checkpoint/trace.json)、[逐例回执](checkpoint/execution-tool-fix.json)、[质量审查](checkpoint/quality.json)及主控独立复核 |
| 接续 | [冻结包](checkpoint/handoff.json)、revision=2 的记录、下一动作及授权范围；下一独立上下文从 L7 开始 |

在集合根目录验证已冻结包与接续守卫：

```sh
python3 scripts/lifecycle_quality.py handoff --root skills/project-docs-lifecycle/assets/examples/open-case/checkpoint --contract handoff.json
PYTHONPATH=scripts python3 -m unittest test_lifecycle_quality test_lifecycle_handoff
```

重新执行业务测试请先将 checkpoint 整目录复制到新的工作目录，再运行当前采集器，将输出写到新的回执文件，不覆盖检查点。快照中的 tooling 保留当时执行工具；使用其他工具版本复核时必须重新采集当前版本测试证据。

这里的业务角色答复、UAT 和批准只允许作为模拟输入。本地子进程执行与摘要校验不能证明真实业务接受、生产权限、效果收益或桌面聊天自动切换；完整接续结果见验证说明及本轮独立执行报告。

本轮独立新上下文已从当前检查点实际推进L7–L9：模拟业务验收、隔离目录发布/新进程冒烟、非法输入失败及同构建恢复、支持复跑完成。原身份、PRD、业务代码与83个冻结文件不变；记录CAS推进至revision7并保留历史。L10真实效果缺基线/窗口/Owner/数据，维持pending_confirmation，整体记录未关闭。逐命令证据和全阶段产物随本轮交付包保存；仓库检查点是接续输入，不是每次执行都通过的证明。
